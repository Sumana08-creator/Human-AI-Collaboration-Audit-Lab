# Initial scoring consolidation — Human–AI Collaboration Audit Lab

## Status
HG003–HG006 Condition A first responses have now been pasted into the working conversation after the user was instructed to generate them in fresh chats. The user reports fresh-chat provenance; prompts, model/version and settings have not been independently verified from the run itself. Scores below are **provisional desk assessments**, not independent reviewer ratings.

## Condition A initial responses — provisional scores

| Scenario | Accuracy (0–2) | Evidence fidelity (0–2) | Completeness (0–2) | Traceability (0–2) | Unsupported factual claims identified | Key check |
|---|---:|---:|---:|---:|---:|---|
| HG003 Risk register | 2 | 2 | 2 | 2 | 0 | Correctly says blank action field does not prove no action elsewhere; listed controls' effectiveness unverified. |
| HG004 Audit sampling | 2 | 2 | 2 | 2 | 0 | 16/20 = 80%; 4/20 = 20%; no generalisation to population. |
| HG005 Document control | 2 | 2 | 2 | 2 | 0 | Seven calendar days between 15 and 22 August; does not assume continuous delay or harm. |
| HG006 Monthly complaints | 2 | 2 | 2 | 2 | 0 | Jan→Feb −3 (−25%); Feb→Mar +2 (+22.22%); does not infer cause, rate or service quality. |

The zero counts mean no unsupported material factual claims were identified in this initial desk review; they are not proof that no reviewer could identify any.

## What can be concluded now
- The four pasted Condition A answers are factually aligned with the supplied scenario facts and preserve key uncertainties on this provisional rubric review.
- This does **not** establish that Condition A is better than Condition B, nor that structured revision has no value. We have not yet performed a consistent paired comparison of eligible records.
- HG001 Condition B initial-response provenance remains unresolved.
- HG002 has a duplicate older B initial that must be excluded; the fresh B record still requires source/prompt/context alignment checks.
- For HG003–HG006, the user reports generating Condition A answers in fresh chats, but exact prompts and run metadata should be preserved/verified before a formal comparison.
- All current scores are assistant desk scores. An independent second reviewer scoring a subset would strengthen the pilot.

## Next steps
1. Verify that the exact Condition A prompts used match the frozen source facts and output requirements for each scenario.
2. Check Condition B initial and revised records against the same source facts and rubric; document any prompt/context deviations.
3. Decide in advance how correction success is handled when the initial response contains no material error (recommend `N/A`, not an artificial improvement score).
4. Only then calculate descriptive paired differences for eligible A vs B-initial/B-revised outputs. Report unavailable or ineligible comparisons as missing, not as zero.
5. Do not make causal, statistical-significance, generalisability or safety claims from this small fictional pilot.
