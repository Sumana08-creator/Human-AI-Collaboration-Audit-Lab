# Human–AI Collaboration Audit Lab — Evidence Consolidation and Data-Quality Audit

**Status date:** 18 October 2026  
**Study type:** Exploratory pilot using fictional healthcare governance scenarios. This is not clinical validation and does not involve real patient data or real healthcare workers.

## Work completed in this step
- Consolidated an inventory of available outputs and revision records for HG001–HG006.
- Added an `Evidence_Inventory` sheet to the workbook.
- Added a `Condition_A_Prompt_Pack` sheet with frozen baseline prompts for HG003–HG006.
- Recorded unresolved provenance and comparison-readiness limitations instead of filling missing records with invented data.

## Current evidence inventory
- **HG001:** One-shot report and revised record are available; provenance of the Condition B initial response remains unresolved.
- **HG002:** One-shot answer, a fresh Condition B initial answer and a revised record are available. An earlier Condition B initial record duplicated the one-shot response and must not be treated as independent. Source-prompt alignment and context contamination remain limitations to document.
- **HG003–HG006:** Condition B initial and revised responses/reviews are available. Condition A one-shot outputs are missing.

## What can be said now
The supplied Condition B initial responses for HG003–HG006 appear to preserve the stated facts, calculations and uncertainties. Their revision records report no material factual errors in the initial answers and describe improvements mainly in clarity, organisation, and explicit evidential boundaries. These are provisional desk assessments, not independent reviewer scores.

## What cannot be claimed yet
- A full comparison of Condition A and Condition B across all six scenarios.
- That structured revision improves factual accuracy overall.
- That the provisional scores are validated or independent.
- That the workflow is safe or clinically validated.

## Next valid step
Run the four Condition A baseline prompts in the workbook’s `Condition_A_Prompt_Pack` sheet in fresh chats, with no prior response for that scenario in the chat. Use the same model/version and settings as Condition B where possible. Preserve exact prompts, complete outputs, date/time, model/version and any deviations. Do not add the revision prompt. Then apply the same rubric to all eligible outputs.

## Scoring caution
A revised response cannot demonstrate factual correction when no material factual error existed in the initial answer. Record correction success as `N/A` or use a pre-specified rubric rule for “no correction needed”; do not force a score that implies an error was corrected. Clarity/traceability improvements can be recorded separately from factual accuracy.
