# Prompt templates and source evidence

## Standard initial task prompt
You are assisting with a fictional healthcare governance exercise. Use only the source evidence supplied below. Do not invent facts, dates, policies, causes, or outcomes. Distinguish evidence from inference and recommendation. If evidence is insufficient, say so explicitly. For each material factual claim, identify the source fact that supports it. Do not provide clinical diagnosis or treatment advice.

## Standard Condition B revision prompt
Review your previous answer only against the source evidence and required output elements provided in the original task. Identify each factual claim that is unsupported, contradictory, incomplete, or not traceable to the evidence. Then provide a revised answer. Do not add new facts or external knowledge. Mark unresolved uncertainty explicitly. Include a short correction log listing each change and the source evidence supporting it.

## HG001 — Training completion
Register lists 40 staff. Training records show 32 completed the required module by 30 September. Eight records are marked not completed. Local target is at least 90%. No reason for non-completion is recorded. Required: numerator, denominator, percentage, target comparison, no invented reasons, proportionate next step.

## HG002 — Delayed equipment check
Equipment check due 4 May and completed 6 May. Reason for delay and whether harm occurred are unknown. Do not infer cause or consequences. A two-calendar-day difference is calculable from dates; exact elapsed hours are not provided.

## HG003 — Risk register
Handover information is incomplete. A template and monthly spot checks are listed as existing controls. Action field in the risk register is blank. No risk scores or incident counts are provided.

## HG004 — Audit sampling
A sample of 20 records was reviewed; 16 were compliant; 4 had exceptions. Sampling method is unknown. No evidence establishes whether the sample represents all records.

## HG005 — Document control
A document-control checklist action was due 15 August. On 22 August its status remained “in progress.” Reason for delay and impact are unknown.

## HG006 — Complaints trend
Recorded complaint counts: January 12, February 9, March 11. No service volume, complaint severity, complaint categories or reporting-change context is supplied.
