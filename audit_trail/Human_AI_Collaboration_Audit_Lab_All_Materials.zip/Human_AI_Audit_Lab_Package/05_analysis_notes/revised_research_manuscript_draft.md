# When Heat Becomes Preventable Harm: A Simulation Study of Heat-Related Mortality, Age Vulnerability, and Hypothetical Health-System Capacity

## Abstract

### Background
Heat-related mortality analyses require explicit decisions about exposure definitions, population denominators, outcome distributions, and effect heterogeneity. Before applying a statistical workflow to observed data, simulation can help assess how the workflow behaves under known assumptions.

### Aim
This methodological simulation study examines coefficient recovery, model comparison, sensitivity to the assumed heat threshold, and temporal holdout prediction in a synthetic heat–mortality setting.

### Methods
A synthetic daily dataset covering 2019–2025 was generated for three hypothetical regions and six age groups, producing 46,026 region–age-group–day observations. A hypothetical population of one million was allocated across the groups. Synthetic death counts were generated using a Poisson process with programmed heat-vulnerability and capacity terms. Three Poisson regression specifications were compared using Akaike’s information criterion (AIC), deviance, and Pearson dispersion. A 100-repetition Monte Carlo experiment assessed coefficient recovery. Threshold sensitivity was evaluated at 18°C, 20°C, and 22°C. Temporal holdout prediction used 2019–2023 for training and 2024–2025 for testing.

### Results
The vulnerability-scaled heat model had the lowest AIC (85,067.75), but its AIC advantage over the common-effect model was small (ΔAIC = 1.51). Across 100 Monte Carlo repetitions, the mean heat coefficient was 0.02731 against a programmed value of 0.025; the mean capacity coefficient was −0.23263 against a programmed value of −0.25. The fitted heat coefficient varied substantially across assumed thresholds. In the held-out period, the baseline, common-effect, and vulnerability-scaled models had MAE values of 0.57606, 0.57612, and 0.57607, respectively, with very small differences in RMSE and aggregate totals.

### Conclusion
The results illustrate how simulation-based parameter recovery, model comparison, exposure sensitivity, and temporal holdout evaluation can be brought together in a transparent workflow. The observed differences between predictive models were small. All results are conditional on the synthetic data-generating process and do not establish empirical associations, causal effects, or predictive accuracy for observed Belgian mortality.

**Keywords:** heat; mortality; simulation study; Poisson regression; age vulnerability; model comparison; reproducibility

---

## 1. Introduction

High temperatures can pose public-health challenges, and the consequences of heat exposure may differ across age groups and social and health-system contexts. A systematic review and meta-analysis found evidence of increased vulnerability to heat-related mortality among older age groups, while also identifying areas where evidence was less conclusive (Benmarhnia et al., 2015). Temperature–mortality analyses can also require flexible representations of exposure–response relationships and delayed effects, such as distributed lag non-linear models (Gasparrini et al., 2010).

Before applying a statistical workflow to empirical mortality data, a simulation study can help determine how the workflow behaves under specified assumptions. Because the data-generating process is known, simulation permits direct comparison between programmed parameters and fitted estimates. Good simulation practice requires clearly defined aims, data-generating mechanisms, methods, estimands, and performance measures (Morris et al., 2019), together with transparent reporting of design, code, and analysis decisions (Williams et al., 2024).

The present study is a methodological demonstration. It does **not** estimate the observed association between temperature and mortality in Belgium. It uses hypothetical regional populations, age-specific baseline mortality rates, heat-vulnerability values, and capacity measures to examine a statistical workflow under a specified synthetic data-generating process.

### Research questions

1. How closely do fitted Poisson regression coefficients recover parameters used to generate synthetic mortality counts?
2. How do alternative heat-exposure specifications compare under AIC?
3. How sensitive are estimated heat associations to alternative exposure thresholds?
4. How do a baseline model and two heat-model specifications perform when predicting a later synthetic period?
5. What limitations must be addressed before applying this workflow to empirical mortality data?

## 2. Methods

### 2.1 Study design

The analysis used a synthetic daily dataset covering 1 January 2019 through 31 December 2025. The design contained three hypothetical regions and six age groups, yielding 46,026 region–age-group–day observations across 2,557 days and 18 region–age-group combinations.

The dataset represents a computational experiment, not a reconstruction of actual Belgian demographic, temperature, or mortality patterns.

### 2.2 Synthetic temperature series

Daily temperatures were generated using a seasonal sinusoidal component, random noise, and a temporal-persistence transformation. Values were bounded between −10°C and 42°C. The temperature series is synthetic; its distribution and temporal structure should not be interpreted as an empirical validation of Belgian weather.

### 2.3 Population and age groups

The hypothetical population was one million, allocated across three regions and six age groups using predefined shares. The age groups were 0–17, 18–39, 40–64, 65–74, 75–84, and 85+ years. Each group had an assumed baseline annual mortality rate and heat-vulnerability value.

These allocations were selected for the simulation and are not observed Belgian population estimates.

### 2.4 Mortality data-generating process

For each region–age-group–day observation, the expected death count was generated using a Poisson model. The programmed log rate-ratio component was:

\[
\log(RR_{it}) = 0.025\,H_t V_i - 0.25(C_{it}-0.65),
\]

where:

- \(H_t = \max(T_t - 20, 0)\) is heat exposure above the assumed 20°C threshold;
- \(V_i\) is the predefined age-group vulnerability value;
- \(C_{it}\) is the hypothetical capacity measure.

The daily baseline mortality rate was the assumed annual age-specific rate divided by 365.25. Expected deaths were calculated as allocated population multiplied by the daily baseline rate and the rate ratio. Synthetic observed counts were then sampled from a Poisson distribution.

The coefficients 0.025 and −0.25 are simulation inputs, not estimates from empirical data. The main data-generating process does not include a heat-by-capacity interaction. Accordingly, this simulation does not test whether a capacity interaction exists in real populations.

### 2.5 Statistical models

Poisson generalized linear models with a log link and population offset were fitted. Three heat specifications were compared:

- **Model A — common heat effect:** a common heat-exposure coefficient with region and age-group terms and capacity.
- **Model B — vulnerability-scaled heat effect:** heat exposure scaled by the predefined age-vulnerability value, with region and age-group terms and capacity.
- **Model C — age-specific heat effects:** separate heat effects by age group, with region terms and capacity.

Models were compared using AIC, deviance, and the Pearson dispersion statistic. A lower AIC indicates a more favourable fit–complexity trade-off among the models being compared; it does not establish causal validity or substantive superiority.

### 2.6 Monte Carlo parameter-recovery experiment

One hundred synthetic mortality datasets were generated and the specified model was refitted to each. Summaries included mean coefficient estimates, bias, relative bias, empirical standard deviation, mean model standard error, confidence-interval coverage, and the proportion of p-values below 0.05.

The finite number of repetitions limits the precision of estimated simulation properties. The proportion of p-values below 0.05 for the non-zero programmed parameters is not a Type I error rate; it is a detection proportion under the specified scenarios.

### 2.7 Heat-threshold sensitivity analysis

The fitted heat-exposure threshold was varied across 18°C, 20°C, and 22°C while the underlying synthetic mortality counts remained unchanged. This assesses sensitivity to the fitted exposure definition rather than comparing three separately generated datasets. Because the exposure variable changes with the threshold, the resulting coefficients are not directly comparable as effects per identical exposure unit.

The thresholds are modelling choices for this simulation, not validated or official Belgian public-health thresholds.

### 2.8 Temporal holdout evaluation

Models were fitted using the 2019–2023 period and evaluated on the 2024–2025 period. The held-out set contained 13,158 observations. Performance measures were mean absolute error (MAE), root mean squared error (RMSE), mean prediction error, and aggregate prediction error. The baseline model excluded the heat predictor; the two alternative models were the common-effect and vulnerability-scaled specifications.

Because outcomes and covariates were synthetic, this exercise assesses prediction within the simulated environment, not transportability to real populations.

### 2.9 Reproducibility and reporting

The project contains scripts and saved outputs for the simulation, validation, model comparison, sensitivity analysis, prediction evaluation, and figures. The primary simulation uses a fixed random seed. However, the existence of saved outputs and a fixed seed alone does not demonstrate that the entire project has been regenerated successfully from a clean environment. A complete clean-run test, dependency check, and output comparison remain necessary before making a strong reproducibility claim. Reporting choices are informed by published guidance for simulation studies (Morris et al., 2019; Williams et al., 2024).

## 3. Results

### 3.1 Dataset checks

The synthetic dataset contained 46,026 observations covering 2019–2025. The reported data-quality checks found no missing cells, negative death counts, or non-positive population values. The unique region–age-group population allocations summed to one million.

These checks establish internal consistency for the generated dataset; they do not establish that its values represent real populations.

### 3.2 Model comparison

| Model | Observations | Log-likelihood | Deviance | AIC | Pearson dispersion |
|---|---:|---:|---:|---:|---:|
| Model A — common heat effect | 46,026 | −42,524.629 | 39,391.224 | 85,069.258 | 0.99749 |
| Model B — vulnerability-scaled | 46,026 | −42,523.876 | 39,389.718 | **85,067.752** | 0.99730 |
| Model C — age-specific effects | 46,026 | −42,522.959 | 39,387.884 | 85,075.918 | 0.99727 |

Model B had the lowest AIC. Its AIC was 1.51 lower than Model A and 8.17 lower than Model C. The small difference between Models A and B provides limited evidence of a meaningful advantage for Model B. Model C had the lowest deviance but the highest AIC, illustrating that a lower deviance alone does not determine the preferred model when model complexity is penalised.

The Pearson dispersion statistics were close to one for all three fitted models. This is a descriptive diagnostic for these fitted models, not proof that all distributional assumptions are satisfied.

### 3.3 Monte Carlo parameter recovery

| Parameter | Programmed value | Mean estimate | Bias | Relative bias | 95% CI coverage | Proportion p < 0.05 |
|---|---:|---:|---:|---:|---:|---:|
| Heat | 0.025 | 0.027309 | 0.002309 | 9.24% | 0.93 | 0.47 |
| Capacity | −0.25 | −0.232628 | 0.017372 | 6.95% | 0.97 | 0.15 |

Across 100 repetitions, the mean estimated heat coefficient was 0.027309, compared with the programmed value of 0.025. The mean capacity-coefficient estimate was −0.232628, compared with the programmed value of −0.25. The mean model standard errors and empirical standard deviations were of similar magnitudes for heat and capacity, but coverage and detection summaries remain uncertain because only 100 repetitions were performed.

These findings show imperfect coefficient recovery under the fitted specification. They are diagnostics for this particular simulation design, not a general guarantee of model validity.

### 3.4 Heat-threshold sensitivity

| Assumed threshold | Heat coefficient | Standard error | p-value | Rate ratio per model-specific interaction unit | 95% CI for coefficient | AIC |
|---:|---:|---:|---:|---:|---:|---:|
| 18°C | 0.007475 | 0.004832 | 0.121842 | 1.00750 | −0.001995 to 0.016945 | 85,070.994 |
| 20°C | 0.032722 | 0.013609 | 0.016196 | 1.03326 | 0.006049 to 0.059396 | **85,067.752** |
| 22°C | 0.198701 | 0.096816 | 0.040135 | 1.21982 | 0.008942 to 0.388461 | 85,069.476 |

The estimated coefficient changed substantially across the three fitted thresholds. The 20°C model had the lowest AIC among these alternatives. However, these results do not establish 20°C as a universally correct or empirically validated threshold. Since the exposure scale changes with the threshold, coefficient magnitudes and associated rate ratios should be interpreted within each specification rather than compared as if they represented identical exposure increments.

### 3.5 Held-out prediction

| Model | Test observations | MAE | RMSE | Mean prediction error | Actual total | Predicted total | Total percentage error |
|---|---:|---:|---:|---:|---:|---:|---:|
| Baseline — no heat predictor | 13,158 | **0.576056** | 0.844621 | −0.001074 | 9,371 | 9,356.869 | −0.150795% |
| Model A — common heat effect | 13,158 | 0.576115 | 0.844432 | −0.000535 | 9,371 | 9,363.957 | **−0.075160%** |
| Model B — vulnerability-scaled | 13,158 | 0.576065 | **0.844374** | −0.000557 | 9,371 | 9,363.672 | −0.078194% |

The baseline model had the lowest MAE, Model B had the lowest RMSE, and Model A had the smallest absolute aggregate prediction error. The differences were very small. These results do not demonstrate a convincing predictive advantage for either heat model over the baseline or over each other.

Aggregate totals close to the synthetic observed total do not imply that individual observations are predicted accurately. These metrics do not establish predictive accuracy for observed Belgian mortality.

## 4. Discussion

This computational demonstration combines a synthetic data-generating process with Poisson regression, parameter-recovery analysis, model comparison, threshold sensitivity analysis, and temporal holdout evaluation.

The vulnerability-scaled specification had the lowest AIC in the initial model comparison, but its advantage over the common-effect model was small. The age-specific model had a lower deviance but a higher AIC, showing that greater flexibility did not translate into the best AIC in this dataset. The model ranking is conditional on the selected synthetic data-generating process and fitted specifications.

The Monte Carlo results showed that the average fitted coefficients did not exactly equal their programmed values. The heat coefficient had relative bias of approximately 9.24%, and the capacity coefficient had relative bias of approximately 6.95%. These results reinforce the importance of assessing recovery over repeated datasets and reporting uncertainty rather than relying on a single fitted model. With 100 repetitions, the Monte Carlo summaries themselves have finite simulation uncertainty.

Estimated heat coefficients were sensitive to the assumed exposure threshold. This is expected to some extent because changing the threshold changes the definition and scale of the exposure variable. The lowest AIC occurred at 20°C among the three tested specifications, but this is not evidence that 20°C is the correct threshold for observed Belgian mortality.

The held-out prediction results were very similar across the baseline and heat models. The baseline had marginally lower MAE, Model B marginally lower RMSE, and Model A the smallest absolute aggregate prediction error. These small differences do not support a strong claim that adding the heat specification improves predictive performance. Moreover, the holdout evaluates later observations generated under the same synthetic design; it is not external validation.

Finally, the simulation does not establish that healthcare capacity modifies heat-related mortality in real populations. Capacity is hypothetical, and the main data-generating process imposes a capacity term but no heat-by-capacity interaction. The results cannot support a causal claim about real health-system capacity.

## 5. Limitations

The principal limitations are:

1. **Synthetic outcomes:** mortality counts are generated rather than observed.
2. **Hypothetical population structure:** population and age distributions are simulation choices, not empirical Belgian estimates.
3. **Hypothetical capacity measure:** no observed health-system capacity indicator is used.
4. **Model specification:** fitted models do not necessarily reproduce every feature of the data-generating process.
5. **Monte Carlo precision:** 100 repetitions provide limited precision for estimating coverage, bias, and other simulation properties.
6. **Threshold sensitivity:** the alternative thresholds are modelling choices, not clinically or epidemiologically validated Belgian thresholds.
7. **Temporal holdout:** training and testing use different periods of the same synthetic design and do not constitute external validation.
8. **Dependence and uncertainty:** the current analysis does not comprehensively assess all forms of temporal dependence, parameter uncertainty, or alternative mortality-generating mechanisms.
9. **Causal inference:** the analysis cannot establish causal effects of heat or healthcare capacity.
10. **Empirical applicability:** application to real mortality data would require data-quality assessment, exposure alignment, appropriate population denominators, confounder control, and suitable temporal and spatial modelling.
11. **Reproducibility status:** saved outputs and a fixed random seed are not substitutes for a documented clean run that regenerates the results from the published code and environment.

## 6. Conclusion

This study demonstrates a simulation-based workflow for examining synthetic heat–mortality relationships. It compares programmed parameters with fitted coefficients, evaluates alternative exposure specifications, assesses threshold sensitivity, and measures prediction performance in a chronological synthetic holdout.

The vulnerability-scaled model had the lowest AIC among the three initial model specifications, but its advantage over the common-effect model was small. Predictive performance differences were also small, and no model showed a convincing overall advantage across all reported metrics. Estimated heat coefficients varied with the assumed exposure threshold.

All findings are conditional on the specified synthetic data-generating process. They should not be interpreted as empirical estimates of Belgian heat-related mortality, proof of predictive validity for observed populations, or evidence of a protective or causal effect of healthcare capacity. A subsequent empirical study would require appropriately validated observed temperature, mortality, population, and health-system data, alongside a prespecified analysis plan and suitable temporal and spatial methods.

## Data and code statement

The reported analyses use synthetic mortality outcomes and hypothetical population and capacity measures generated by project scripts. Any empirical source files retained in the project must be clearly distinguished from the synthetic data and must not be published without confirming their licensing, privacy status, and permission for redistribution. The code and synthetic outputs should be released only after a clean-run reproducibility check and a review for accidental inclusion of confidential or personal files.

## Ethics statement

The reported simulation uses synthetic mortality outcomes and does not analyse individual-level observed mortality records. Any future empirical analysis would require a separate assessment of data access permissions, governance, ethics requirements, and disclosure risks.

## Funding and conflicts of interest

**Funding:** To be completed by the author.

**Conflicts of interest:** To be completed by the author.

## References

Benmarhnia, T., Deguen, S., Kaufman, J. S., & Smargiassi, A. (2015). Vulnerability to heat-related mortality: A systematic review, meta-analysis, and meta-regression analysis. *Epidemiology, 26*(6), 781–793. https://doi.org/10.1097/EDE.0000000000000375

Gasparrini, A., Armstrong, B., & Kenward, M. G. (2010). Distributed lag non-linear models. *Statistics in Medicine, 29*(21), 2224–2234. https://doi.org/10.1002/sim.3940

Morris, T. P., White, I. R., & Crowther, M. J. (2019). Using simulation studies to evaluate statistical methods. *Statistics in Medicine, 38*(11), 2074–2102. https://doi.org/10.1002/sim.8086

Williams, C., Yang, Y., Lagisz, M., Morrison, K., Ricolfi, L., Warton, D. I., & Nakagawa, S. (2024). Transparent reporting items for simulation studies evaluating statistical methods: Foundations for reproducibility and reliability. *Methods in Ecology and Evolution, 15*(11), 1926–1939. https://doi.org/10.1111/2041-210X.14415

---

## Author checks before submission

- Confirm the title and author details.
- Complete funding and conflict-of-interest declarations.
- Confirm the exact model formulas, offsets, reference categories, and fitting settings against the analysis scripts.
- Verify all numerical tables against the saved output files after a clean run.
- Document the software versions and dependency installation process.
- Confirm that the clean run reproduces the reported outputs before describing the workflow as fully reproducible.
- Review all files intended for public release. Do not upload private mortality source files, personal documents, credentials, or files whose redistribution rights are unclear.
- Add any further relevant literature only after verifying the source and ensuring that it directly supports the statement cited.
