# HG006 — Complaints Trend Review

**Workflow:** Evidence-based governance review
**Stage:** Initial response

## 1. Monthly Complaint Counts and Changes

The recorded complaint counts for January, February and March were 12, 9 and 11, respectively.

| Month | Recorded complaints | Change from previous month | Percentage change |
|---|---:|---:|---:|
| January | 12 | — | — |
| February | 9 | −3 | −25.0% |
| March | 11 | +2 | +22.2% |

**Source evidence:** The supplied records list 12 complaints in January, 9 in February and 11 in March.

**Calculations:** January to February: 9 − 12 = −3; (−3 ÷ 12) × 100 = −25.0%. February to March: 11 − 9 = +2; (2 ÷ 9) × 100 ≈ +22.2%. January to March: 11 − 12 = −1, approximately an 8.3% decrease relative to January.

## 2. What the Figures Establish

The recorded complaint count decreased from 12 in January to 9 in February, then increased to 11 in March. These figures establish changes in recorded complaint counts only. They do not establish whether the underlying complaint rate changed, whether service quality improved or deteriorated, or whether the changes represent a meaningful trend.

## 3. Missing Information and Uncertainties

The source does not provide service volume, complaint severity, complaint categories or information about changes in reporting practices. Therefore, it cannot establish complaint rates relative to service volume, seriousness, complaint types or the effect of reporting changes.

## 4. Recommendations

These are recommendations, not confirmed actions or established requirements: review complaint categories and severity; obtain service-volume data if available; verify reporting consistency; and continue monitoring counts with relevant context.

## 5. Evidence-Based Conclusion

Recorded complaints decreased from 12 in January to 9 in February, then increased to 11 in March. March was one complaint below January. The available evidence does not establish why the counts changed or whether they reflect service quality, underlying complaint rates, severity or reporting practices.
