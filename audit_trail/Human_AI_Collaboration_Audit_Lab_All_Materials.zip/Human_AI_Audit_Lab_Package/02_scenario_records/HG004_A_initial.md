# HG004 — Audit Sampling Summary

**Workflow:** Evidence-based governance review
**Stage:** Initial response

## 1. Key Findings

A sample of 20 records was reviewed. Of these, 16 were compliant, giving a **sample compliance rate of 80%**.

**Calculation:** (16 ÷ 20) × 100 = 80%.

**Source evidence:** The supplied records state that 20 records were reviewed and 16 were compliant.

This result describes the reviewed sample only. It does not establish the compliance rate across all records.

## 2. Exceptions Identified

Four records had exceptions.

**Source evidence:** The supplied evidence explicitly states that four records had exceptions.

The evidence does not describe the nature, severity or causes of these exceptions. No further conclusions about them can be drawn from the available information.

## 3. Sampling Limitations

- **Sampling method unknown:** The evidence does not explain how the 20 records were selected.
- **Representativeness unestablished:** No evidence establishes whether the sample represents all records.

Consequently, the sample compliance rate of 80% cannot be assumed to represent the compliance rate across the entire record population. The available evidence also does not establish the overall number of records or the prevalence of exceptions outside the sample.

## 4. Recommendations

The following are recommendations, not confirmed actions or established requirements.
1. **Clarify the sampling method:** Establish how the 20 records were selected and document the method used, if this information is available.
2. **Assess representativeness:** Determine whether the sample supports conclusions about the wider record population.
3. **Review the exceptions:** Examine the four exception records to establish their nature and significance before determining whether further action is warranted.
4. **Document limitations:** Ensure that any reporting clearly distinguishes sample findings from conclusions about all records.

## 5. Conclusion

The review identified **16 compliant records out of 20, representing an 80% sample compliance rate, with four exceptions**.

Because the sampling method is unknown and the sample's representativeness has not been established, the results cannot reliably establish the compliance rate across all records.

**Recommended next step:** Clarify the sampling method and review the four exceptions before drawing broader conclusions or determining further action.
